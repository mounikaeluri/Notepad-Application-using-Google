package edu.sdsu.cs645.client;

import edu.sdsu.cs645.shared.FieldVerifier;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.*;
import java.util.*;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Notepad implements EntryPoint {
 
  private static final String SERVER_ERROR = "An error occurred while "
      + "attempting to contact the server. Please check your network "
      + "connection and try again.";
 
  private final NotepadServiceAsync notepadService = GWT.create(NotepadService.class);
  private RichTextArea pad;
  private HTML status;

  public void onModuleLoad() {
  status = new HTML();
  //buildMainPanel();
  buildLogin();
     }
	 private void buildLogin(){
	 FlowPanel loginPanel=new FlowPanel();
	 loginPanel.getElement().setId("log_panel");
	 final PasswordTextBox password=new PasswordTextBox();
	 loginPanel.add(new HTML("<h1> Please enter your password</h1>"));
	 loginPanel.add(new Label("Password"));
	 loginPanel.add(password);
	 FlowPanel bPanel=new FlowPanel();
	 bPanel.setStyleName("blog_panel");
	 Button loginButton = new Button("login");
	 Button clearButton = new Button("clear");
	 loginButton.setStyleName("log_button");
	 clearButton.setStyleName("log_button");
	 clearButton.addClickHandler(new ClickHandler(){
	 public void onClick(ClickEvent e){
	 password.setText(" ");
	 }
	 });
	 loginButton.addClickHandler(new ClickHandler(){
	 public void onClick(ClickEvent e){
	 validateLogin(password.getText());
	 }
	 });
	 bPanel.add(clearButton);
	 bPanel.add(loginButton);
	 loginPanel.add(bPanel);
	 loginPanel.add(status);
	 RootPanel.get().add(loginPanel);
	 password.setFocus(true);
	 }
	 
		 	 
  private void buildMainPanel(){
  FlowPanel main = new FlowPanel();
  main.add(new HTML("<h1>Online Notepad </h1>"));
  main.add(getButtonPanel());
  pad = new RichTextArea();
  main.add(pad);
  main.add(status);
  RootPanel.get().clear();
  RootPanel.get().add(main);
  loadPanel();
  }
  private FlowPanel getButtonPanel(){
  FlowPanel p = new FlowPanel();
  Button save = new Button("Save");
  Button load = new Button("Load");
  Button loadMap = new Button("Load Map");
  save.setStyleName("my_button");
  load.setStyleName("my_button");
  loadMap.setStyleName("my_button");
  save.addClickHandler(new ClickHandler(){
  public void onClick(ClickEvent e)
  {
  savePanel();
  }
  });
  load.addClickHandler(new ClickHandler(){
  public void onClick(ClickEvent e)
  {
  loadPanel();
  }
  });
  loadMap.addClickHandler(new ClickHandler(){
  public void onClick(ClickEvent e)
  {
  loadMap();
  }
  });
  p.setStyleName("button_panel");
  p.add(save);
  p.add(load);
  p.add(loadMap);
  return p;
  }
  private void savePanel(){
  AsyncCallback callback = new AsyncCallback(){
  public void onSuccess(Object results)
  {
  status.setText((String) results);
  }
  public void onFailure(Throwable err){}
  };
  notepadService.save(pad.getHTML(),callback);
  }
  
  private void loadPanel(){
  AsyncCallback callback = new AsyncCallback(){
  public void onSuccess(Object results)
  {
  pad.setHTML((String) results);
  }
  public void onFailure(Throwable err){}
  };
  notepadService.load(callback);
  }
  
 private void loadMap(){
  AsyncCallback callback = new AsyncCallback(){
  public void onSuccess(Object results)
  {
  TreeMap t = (TreeMap) results;
  String toDisplay = "<table>";
  Iterator<String> k = t.keySet().iterator();
  Iterator<String> v = t.values().iterator();
  while (k.hasNext()){
  toDisplay += "<tr>";
  toDisplay += "<td>"+k.next()+"</td>";
  toDisplay += "<td>"+v.next()+"</td>";
  toDisplay += "</tr>";
  }
  toDisplay += "</table>";
  pad.setHTML(toDisplay);
  }
  public void onFailure(Throwable err){}
  };
  notepadService.loadMap(callback); 
  } 
  
  private void validateLogin(String password){
  AsyncCallback callback = new AsyncCallback(){
  public void onSuccess(Object results)
  {
  String answer=((String) results);
  if(answer.equals("OK")){
  status.setText("");
  buildMainPanel();
  }
  else
  status.setText("Invalid Password");
  }
  public void onFailure(Throwable err){
  status.setText("Failed"+err.getMessage());
  }
  };
  notepadService.validateLogin(password,callback);
  }
  }
  